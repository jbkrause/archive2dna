En 2022, dans le cadre du centième anniversaire de l’Association des 
archivistes suisses (AAS-VSA), les institutions membres vaudoises se 
sont décrites selon la norme internationale pour la description 
des institutions de conservation des archives (ISDIAH).

Cette description a été enregistrées dans un format de préservation à
très long terme : un tableau de texte, dont les colonnes sont délimitées 
par des points-virgules (comma-separated values - CSV) avec le codage de 
caractères unicode UTF-8.

Ces données ont ensuite été conditionnées sous la forme d’un paquet
d’archivage numérique par le système de préservation digitale suisse
OLOS (https://olos.swiss/). Ce dernier respecte formellement les 
standards ISO 14721 (OAIS) et RFC 8493 (BagIt), ainsi que les schéma 
de métadonnées DataCite(https://schema.datacite.org/), PREMIS 
(https://www.loc.gov/standards/premis/) et METS 
(http://www.loc.gov/standards/mets/).

Finalement, ce paquet d’archivage a été encodé dans l’ADN dans le cadre
d'un premier test l’outil open source archive2dna
(https://github.com/jbkrause/archive2dna). Ce logiciel se base sur les
résultats du laboratoire Functional Material Laboratory de l'École
polytechnique fédérale de Zurich (ETHZ), et notamment la publication :
Meiser, Linda C., Philipp L. Antkowiak, Julian Koch, Weida D. Chen, 
A. Xavier Kohll, Wendelin J. Stark, Reinhard Heckel, et Robert N. Grass. 
"Reading and Writing Digital Data in DNA". Nature Protocols 15, 
no 1 (january 2020): 86 101. https://doi.org/10.1038/s41596-019-0244-5.
